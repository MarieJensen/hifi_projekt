const db = require('../config/sql').connect();
const security = require('../services/security');

module.exports = function (app) { // betyder at andre filer kan hente funktionen vha. req
    app.get('/produkter', function (req, res) { // selve routet som har get metoden. Her vises alle produkter.
        db.query(`SELECT produkter.ID, produkter.navn, produkter.pris, produkter.beskrivelse, produkter.billede, kategori.kategori AS type, producent.producent 
                    FROM produkter INNER JOIN kategori ON produkter.fk_kategori_id = kategori.ID 
                    INNER JOIN producent ON produkter.fk_producent = producent.ID ORDER BY kategori.kategori
                    `, function (err, data) {
                res.send(data);
            })
    });


    app.get('/produkt/:id', function (req, res, id) { // selve routet som har get metoden. Her vises et produkt. 
        db.query(`SELECT produkter.ID, produkter.navn, produkter.pris, produkter.beskrivelse, produkter.billede FROM produkter where produkter.id = ?`, [req.params.id], function (err, data) {
            res.send(data);
        })
    });

    app.get('/produkter/:id', function (req, res, id) { // selve routet som har get metoden. Her vises kategori liste
        db.query(`SELECT produkter.ID, produkter.navn, produkter.pris, produkter.beskrivelse, produkter.billede, kategori.kategori AS type, producent.producent FROM produkter INNER JOIN kategori ON produkter.fk_kategori_id = kategori.ID INNER JOIN producent ON produkter.fk_producent = producent.ID where produkter.fk_kategori_id = ?`, [req.params.id], function (err, data) {
            res.send(data); 
        })
    });


    app.post('/opretkategori', security.isAuthenticated, function (req, res, next) { // Route som opretter en ny kategori
        
                let kategori = req.body.kategori;
        
                console.log(kategori);
        
                let sql = `INSERT INTO kategori(ID,kategori)values(null,?)`;
        
                db.query(sql, [kategori], function (err, data) {
        
                    if (err) {
                        console.log(err);
                    } else {
                        res.send("Ok");
                    }
                })
        
            });
        


    app.post('/produkt', security.isAuthenticated, function (req, res, next) { // selve routet som har post metoden. Her oprettes produkter.

        let navn = req.body.navn;
        let pris = req.body.pris;
        let beskrivelse = req.body.beskrivelse;
        let kategori_id = req.body.kategori_id;
        let producent_id = req.body.producent_id;
        let billede = req.body.billede;
        console.log(navn);

        //    console.log(navn);
        //     console.log(email);
        //     console.log(besked);

        let sql = `INSERT INTO produkter(ID, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede) VALUES (null,?,?,?,?,?,"pladespiller.jpg")`;

        db.query(sql, [navn, pris, beskrivelse, kategori_id, producent_id, billede], function (err, data) {

            if (err) {
                console.log(err);
            } else {
                res.send("Ok");
            }
        })

    });


    app.put('/produkt/:id', security.isAuthenticated, function (req, res, next) { // selve routet som har put metoden. Her opdateres produkter.

        let navn = req.body.navn;
        let pris = req.body.pris;
        let beskrivelse = req.body.beskrivelse;
        let kategori_id = req.body.kategori_id;
        let producent_id = req.body.producent_id;
        console.log(navn, kategori_id, producent_id);
        
        let sql = `UPDATE produkter SET navn=?,pris=?,beskrivelse=?,fk_kategori_id=?,fk_producent=? WHERE ID=?`;

        db.query(sql, [navn, pris, beskrivelse, kategori_id, producent_id, req.params.id], function (err, data) {

            if (err) {
                console.log(err);
            } else {
                res.send("Ok");
            }
        })

    });


    app.del('/produkt/:id', security.isAuthenticated, function (req, res, next) { // selve routet som har delete metoden. Her slettes produkter.

                let sql = `DELETE FROM produkter WHERE ID=?`;

                db.query(sql, [req.params.id], function (err, data) {

                    if (err) {
                        console.log(err);
                    } else {
                        res.send("Ok");
                    }
                })

            });

}

