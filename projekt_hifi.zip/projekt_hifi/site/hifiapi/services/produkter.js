// frugt-servicen har brug for database adgang
const mysql = require('mysql2');
const db = require('../config/sql').connect();
db.connect((err) => {
   if (err) {
      console.log(Date(), err.stack);
      return;
   }
});

// function create(callback, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede) { // funktionen hedder create og har to parametre/argumenter, et callback og et id. 
    
//             var sql = `insert into produkter values ?`; 
//             var values = [null, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede];
    
//             db.query(sql, [[values]], function (err, result) { // funktion som indeholder to argumenter: err og result
//                 if (err)
//                     callback(err, null); // hvis der er fejl bliver resultatet null
//                 else
//                     callback(null, result); // hvis der ikke er fejl får jeg resultatet
//             });
//         }

// function update(callback, id, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede) { // funktionen hedder update og har to parametre/argumenter, et callback og et id. 

//             var sql = `UPDATE produkter SET navn = ?, pris = ?, beskrivelse = ?, fk_kategori_id = ?, fk_producent = ?  WHERE id = ? `; 
            
//             db.query(sql, [null, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede], function (err, result) { // funktion som indeholder to argumenter: err og result
//                 if (err)
//                     callback(err, null); // hvis der er fejl bliver resultatet null
//                 else
//                     callback(null, result); // hvis der ikke er fejl får jeg resultatet
//             });
//         } 

// function delete_bolche(callback, id) { // funktionen hedder update og har to parametre/argumenter, et callback og et id. 
            
//             var sql = `DELETE FROM produkter WHERE id = ? `; 
                        
//             db.query(sql, [id], function (err, result) { // funktion som indeholder to argumenter: err og result
//                 if (err)
//                     callback(err, null); // hvis der er fejl bliver resultatet null
//                 else
//                     callback(null, result); // hvis der ikke er fejl får jeg resultatet
//             });
                    
//         } 

//         module.exports = {
//             create,
//             update,
//             delete_bolche
        
//         }