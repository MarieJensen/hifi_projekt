
const db = require('../config/sql').connect();
module.exports = function (app) {
    app.post('/opret', function (req, res) {
        
                let navn = req.body.navn;
                let pris = req.body.pris;
                let beskrivelse = req.body.beskrivelse;
                let fk_kategori_id = req.body.fk_kategori_id;
                let fk_producent = req.body.fk_producent;
                let billede = req.body.billede;
        console.log(navn);
        
            //    console.log(navn);
            //     console.log(email);
            //     console.log(besked);
        
               let sql = `INSERT INTO produkter(ID, navn, pris, beskrivelse, fk_kategori_id, fk_producent, billede) VALUES (null,?,?,?,?,?,"pladespiller.jpg")`;
        
               db.query(sql,[navn,pris,beskrivelse,fk_kategori_id,fk_producent,billede], function (err, data) {
        
                   if (err) {
                        console.log(err);
                    } else {
                        res.send("Ok");
                    }
                })
        
           });
           app.post('/opretkategori', function (req, res) {
            
                    let kategori = req.body.kategori;
                   
            console.log(kategori);
            
              
            
                   let sql = `INSERT INTO kategori(ID,kategori)values(null,?)`;
            
                   db.query(sql,[kategori], function (err, data) {
            
                       if (err) {
                            console.log(err);
                        } else {
                            res.send("Ok");
                        }
                    })
            
               });
}






        