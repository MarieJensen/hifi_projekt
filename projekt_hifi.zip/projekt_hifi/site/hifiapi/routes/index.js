module.exports = (app) => {
    require('./produkter')(app);
    require('./kategoriid')(app);
    require('./sog')(app);
    require('./produktid')(app);
    require('./kontakt')(app);
    require('./login')(app);
    require('./users')(app);
    require('./opret')(app);
};