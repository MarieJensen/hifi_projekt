const db = require('../config/sql').connect();
module.exports = function (app) {
    app.get('/produkt/:id', function (req, res, id) {
        db.query(`SELECT produkter.ID, produkter.navn, produkter.pris, produkter.beskrivelse, produkter.billede FROM produkter where produkter.id = ?`, [req.params.id], function (err, data) {
            res.send(data); 
        })
    });



}

