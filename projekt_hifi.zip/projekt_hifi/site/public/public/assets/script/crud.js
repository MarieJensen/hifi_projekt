
// Oprettelse af produkt/produkter

document.querySelector('#gemm').addEventListener('click', (event2) => {
    console.log('event ok');
    event2.preventDefault();
    let navn = document.querySelector('#navn').value;
    let pris = document.querySelector('#pris').value;
    let beskrivelse = document.querySelector('#beskrivelse').value;
    let fk_kategori_id = document.querySelector('#fk_kategori_id').value;
    let fk_producent = document.querySelector('#fk_producent').value;
    let billede = document.querySelector('#billede').value;
    if (navn == "") {
        alert("Angiv navn");
    } else if (pris == "") {
        alert("Angiv en pris");
    } else if (beskrivelse ==""){
        alert("Angiv en beskrivelse");
    } else if(fk_kategori_id == ""){
        alert('Angiv en kategori');
    } else if(fk_producent == ""){
        alert("Angiv en producent");
    } else{
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let init = {
        method: 'POST',
        headers: headers,
        body: `{"navn":"${navn}","pris":${pris},"beskrivelse":"${beskrivelse}","fk_kategori_id":"${fk_kategori_id}", 
        "fk_producent":"${fk_producent}","billede":"${billede}"}`,
        cache: 'no-cache',
        mode: 'cors'
    };
    console.log('hejhejhej');
    let request = new Request('http://localhost:3000/opret', init);
    console.log('hhhhhh');
    fetch(request)
        .then(response => { console.log(response) }).catch(err => { console.log(err) });
        console.log('ooooo');
}
});

//___________________________________________________________________________________________________________

// Oprettelse af kategori

document.querySelector('#gemmm').addEventListener('click', (event2) => {
    console.log('event ok');
    event2.preventDefault();
    let kategori = document.querySelector('#kategori').value;
    if (kategori == "") {
        alert("Angiv navn");
    } else{
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let init = {
        method: 'POST',
        headers: headers,
        body: `{"kategori":"${kategori}"}`,
        cache: 'no-cache',
        mode: 'cors'
    };
    console.log('hejhejhej');
    let request = new Request('http://localhost:3000/opretkategori', init);
    console.log('hhhhhh');
    fetch(request)
        .then(response => { console.log(response) }).catch(err => { console.log(err) });
        console.log('ooooo');
}
});



