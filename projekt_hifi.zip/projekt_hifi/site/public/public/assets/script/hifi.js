
// Lige høje kolonner

var equalColumns = function () {
    var columns = document.getElementsByClassName('lige_kolonner');

    var length = columns.length;
    var height = 0;

    for(var i = 0; i < length; i++){
        columns[i].style.height = "auto";
    }

    for(var i = 0; i < length; i++){
        if(columns[i].clientHeight > height){
            height = columns[i].clientHeight;
        }
    }
    for(var i = 0; i < length; i++){
        columns[i].style.height = height + "px";
    }
}
equalColumns();
window.addEventListener("resize", equalColumns, true); 


//______________________________________________________________________________________________

// Visning af alle produkter

    (() => {
        document.addEventListener('DOMContentLoaded', () => {
            hentData(0);
        });
    })();
    // Funktion som henter data til visning i content
    // Funktionen har en parameter - hvis tallet nul hentes alt indhold, og hvis større end nul hentes kun denne ene kategori
    function hentData(type = 0) {
        let url = 'http://localhost:3000/produkter';
        if (type > 0) url += '/' + type;
        fetch(url)
            .then((response) => {
                // grib svarets indhold (body) og send det som et json objekt til næste .then()
                return response.json();
            })
            .then((data) => {
                // nu er json objektet lagt ind i data variablen, udskriv data
                console.log(data);
                var type = '';
                document.getElementById('content').innerHTML = "";
                data.forEach(function (item) {
                    if (type != item.type) {
                        document.getElementById('content').innerHTML += `<h2>${item.type}</h2><br>`;
                        type = item.type;
                    }
                    document.getElementById('content').innerHTML += `
                    <div><h3>${item.navn}</h3>
                    <div><img src="./assets/media/${item.billede}"></div>
                    <p>Pris: ${item.pris} kr.</p>
                    <p>Kategori: ${item.type}</p>
                    <p>Producent: ${item.producent}</p>
                    <p><a onclick="hentprodukt(${item.ID})">Læs mere</a><br><br><br></p>
                    </div><hr>
                            `;
                            
                })
            })
    }
    document.querySelector('#selecttype').addEventListener('change', (event) => {
        let obj = document.querySelector('#selecttype');
        hentData(obj.value);
    })

//______________________________________________________________________________________________


// Visning af produkter vha. søgning
    
    document.querySelector('#soge').addEventListener('input', (event) => {
        let obj = document.querySelector('#soge');
        sogebar(obj.value);
    })

    function sogebar(type) {
        let url = 'http://localhost:3000/produkter/sog';
        url += '/' + type;
        fetch(url)
            .then((response) => {
                // grib svarets indhold (body) og send det som et json objekt til næste .then()
                return response.json();
            })
            .then((data) => {
                // nu er json objektet lagt ind i data variablen, udskriv data
                console.log(data);
                // var type = '';
                document.getElementById('content').innerHTML = "";
                data.forEach(function (item) {
                    
                    document.getElementById('content').innerHTML += `
                    <div><h3>${item.navn}</h3>
                    <div><img src="./assets/media/${item.billede}"></div>
                    <p>Pris: ${item.pris} kr.</p>
                    <p>Kategori: ${item.kategori}</p>
                    <p><a onclick="hentprodukt(${item.ID})"> Læs mere</a><br><br><br></p>
                    </div><hr>
                            `;
                            
                })
            })
    }



//______________________________________________________________________________________________

// Visning af et produkt

function hentprodukt(id) {
    let url = 'http://localhost:3000/produkt';
    if (id!=undefined){
        url+= '/' + id;
    }
    fetch(url)
        .then((response) => {
            // grib svarets indhold (body) og send det som et json objekt til næste .then()
            return response.json();
        })
        .then((data) => {
            // nu er json objektet lagt ind i data variablen, udskriv data
            console.log(data);
            var type = '';
            document.getElementById('content').innerHTML = "";
            data.forEach(function (item) {
                if (type != item.type) {
                    document.getElementById('content');
                    type = item.type;
                }
                document.getElementById('content').innerHTML += `
                <div><h3>${item.navn}</h3>
                <div><img src="./assets/media/${item.billede}"></div>
                <p>Pris: ${item.pris} kr.</p>
                <p>Beskrivelse: ${item.beskrivelse}</p>
                </div><hr>
                        `;
                        
            })
        })
}

//______________________________________________________________________________________________

