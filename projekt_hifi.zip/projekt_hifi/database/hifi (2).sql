-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Vært: 127.0.0.1
-- Genereringstid: 06. 10 2017 kl. 12:55:04
-- Serverversion: 5.6.24
-- PHP-version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hifi`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `accesstokens`
--

CREATE TABLE IF NOT EXISTS `accesstokens` (
  `userid` int(11) NOT NULL,
  `token` text NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `formular`
--

CREATE TABLE IF NOT EXISTS `formular` (
  `id` int(11) NOT NULL,
  `navn` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `besked` text NOT NULL,
  `opret` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `formular`
--

INSERT INTO `formular` (`id`, `navn`, `email`, `besked`, `opret`) VALUES
(1, '', '', 'hej', '2017-09-28 09:22:12'),
(2, 'marie', 'marie@hotmail.com', 'hejjjjjjjjj', '2017-09-28 12:18:20'),
(3, 'pia', 'piahan@mhb.dk', 'hej med dig', '2017-09-28 13:16:03'),
(4, 'marie', 'marieholger@hotmail.', 'ffhdh', '2017-09-29 08:56:48'),
(5, 'marie', 'marieholger@hotmail.', 'hej med dig nnnnnnnnnnnnnnnnnnn', '2017-09-29 08:58:50'),
(6, 'marie', 'marieholger@hotmail.', 'ghjfgh', '2017-09-29 08:59:46'),
(7, 'marie', 'marieholger@hotmail.', 'hey det er vildt det her!', '2017-09-29 09:06:50'),
(8, 'Anne', 'annej@blabla.dk', 'blablabla', '2017-09-29 09:23:58'),
(9, 'Emil', 'emilhansen@blabla.dk', 'gjfhkjfjgjgjkg', '2017-09-29 09:31:41'),
(13, 'ghgh', 'marieholger@hotmail.', 'dghdgh', '2017-09-29 09:54:43'),
(14, 'marie', 'marieholger@hotmail.', 'heyheyheyheyehye', '2017-09-29 11:02:25'),
(15, 'Lisa J', 'Lisajen@hotmail.com', 'Hej jeg elsker jeres butik!', '2017-10-01 14:11:59'),
(16, 'Hans', 'HansJ@hotmail.com', 'Hej jeg er helt vild med jeres produkter!', '2017-10-01 14:19:23'),
(17, 'Natasja', 'natasja@blabla.com', 'hejhejhejhejhejhej', '2017-10-02 08:21:02'),
(18, 'Marie', 'marieholger@hotmail.', 'hdghfjhkhhkfgk', '2017-10-02 12:43:22'),
(19, 'hhej', 'hej@hej.dk', 'gjfjg', '2017-10-04 08:44:15'),
(20, 'Natasja', 'NatasjaAndersen@123.', 'Hey hvad såå?', '2017-10-06 09:23:44');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `ID` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `kategori`
--

INSERT INTO `kategori` (`ID`, `kategori`) VALUES
(1, 'CD Afspillere'),
(2, 'DVD Afspillere'),
(3, 'Effektforstærkere'),
(4, 'Forforstærkere'),
(5, 'Højtalere'),
(6, 'Int. Forstærkere'),
(7, 'Pladespillere'),
(8, 'Rørforstærkere');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `producent`
--

CREATE TABLE IF NOT EXISTS `producent` (
  `ID` int(11) NOT NULL,
  `producent` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `producent`
--

INSERT INTO `producent` (`ID`, `producent`) VALUES
(1, 'Creek Audio Ltd'),
(2, 'Exposure'),
(3, 'Parasound'),
(4, 'Manley'),
(5, 'Pro-ject Audio Systems'),
(6, 'Bösendorfer'),
(7, 'Epos Ltd'),
(8, 'Harbeth Loudspeakers'),
(9, 'Jolida');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `produkter`
--

CREATE TABLE IF NOT EXISTS `produkter` (
  `ID` int(11) NOT NULL,
  `navn` varchar(50) NOT NULL,
  `pris` decimal(10,2) NOT NULL,
  `beskrivelse` text NOT NULL,
  `fk_kategori_id` int(11) NOT NULL,
  `fk_producent` int(11) NOT NULL,
  `billede` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `produkter`
--

INSERT INTO `produkter` (`ID`, `navn`, `pris`, `beskrivelse`, `fk_kategori_id`, `fk_producent`, `billede`) VALUES
(1, 'Creek Classic', '560.00', 'En god klassiker ', 1, 1, 'creek_classic_cd.jpg'),
(2, 'Creek Destiny', '789.00', 'Med Creek Destiny er alt bare på toppen', 1, 1, 'creek_Destiny_CD.jpg'),
(3, 'Creek Evo', '8.00', 'Creek evo er helt i top og bare klar til en god hygge aften.', 1, 1, 'creek_evo_cd.jpg'),
(4, 'Exp 2010S', '10.00', 'En stabil CD afspiller', 1, 1, 'Exp_2010S_CD.gif'),
(5, 'Creek Classic DVD', '99.00', 'den her sparker bare røv til hver en hygge aften', 2, 1, 'creek_classic.jpg'),
(6, 'Exposure 2010S', '99.00', 'exposure er en god for hver en hygge spiller', 2, 2, 'exposure_2010S.jpg'),
(11, 'Parasound D200', '99.00', 'parasound er bare god', 2, 3, 'parasound_d200.jpg'),
(12, 'Parasound Halo p3', '99.00', 'Parasound halo p3 er noget god', 2, 3, 'parasound_halop3.jpg'),
(13, 'Manley Mahi', '99.00', 'manley mahi er en af de bedste til prisen ', 3, 4, 'manley_mahi.jpg'),
(14, 'Manley Neoclassic 300b', '99.00', 'Neoclassic er den bedste til prisen', 3, 4, 'manley_neoclassic300b.jpg'),
(15, 'Manley Snapper', '99.00', 'Snapper er bare fed', 3, 4, 'manley_snapper.jpg'),
(16, 'Parasound Haloa 23', '99.00', 'Parasound haloa 23 er en af de lidt billigere, men den gør det stadig meget godt', 3, 3, 'parasound_haloa23.jpg'),
(17, 'Creek OBH 22 Passive Preamp', '99.00', 'Creek obh er god til prisen', 4, 1, 'Creek_OBH_22_Passive_Preamp.jpg'),
(18, 'Parasound Classic 7100', '99.00', 'Parasound classic 7100 er god til prisen', 4, 3, 'parasound_classic7100.jpg'),
(19, 'parasound halo d3', '99.00', 'Parasound halo d3 er god til prisen', 4, 3, 'parasound_halod3.jpg'),
(20, 'Project Prebox', '99.00', 'Project Prebox er bare god til prisen', 4, 5, 'Project_prebox.jpg'),
(21, 'Boesendorfer Vcs  Wall', '99.00', 'de spiller sinds til prisen', 5, 6, 'boesendorfer_vcs_wall.gif'),
(22, 'Epos m5', '99.00', 'Epos kan bare sparke gang i festen', 5, 7, 'epos_m5.gif'),
(23, 'Harbeth Hl7es2', '99.00', 'Harbeth gir bare den lyd man vil have', 5, 8, 'harbeth_hl7es2.jpg'),
(24, 'harbeth monitor30', '99.00', 'harbeth 30 sparker bare gang i den fest!!', 5, 8, 'harbeth_monitor30.jpg'),
(25, 'Harbeth P3es2', '99.00', 'Harbeth P3es2 er bare vild', 5, 8, 'harbeth_p3es2.jpg'),
(26, 'Creek A50I', '99.00', 'Creek A50l er god til prisen', 6, 1, 'creek_a50I.jpg'),
(27, 'Creek Classic 5350SE', '99.00', 'Creek 5350SE er bare god til prisen', 6, 1, 'creek_classic5350SE.jpg'),
(30, 'Creek Destiny  Amp', '99.00', 'Den gør bare det den skal!', 6, 1, 'creek_Destiny_CD.jpg'),
(31, 'Manley Snapper int._forstaerkere', '99.00', 'Manley snapper er god til prisen', 6, 4, 'manley_neoclassic300b.jpg'),
(32, 'Manley Stingray', '99.00', 'Den er bare god', 6, 4, 'Manley_Stingray.jpg'),
(33, 'Pro Ject Debut 3 BL', '99.00', 'Den spiller godt', 7, 5, 'Pro_ject_Debut_3_bl.jpg'),
(34, 'Pro ject Debut III red 1', '99.00', 'Når damen skal have en god aften så køb den her!!', 7, 5, 'Pro_ject_Debut_III_red_1.jpg'),
(35, 'Pro ject Debut III yellow 1', '99.00', 'Er god til prisen', 7, 5, 'Pro_ject_Debut_III_yellow_1.jpg'),
(36, 'Pro ject rpm 5', '99.00', 'den er bare vild', 7, 5, 'Pro_ject_rpm_5.jpg'),
(37, 'Pro Ject rpm10', '99.00', 'den spiller bare godt', 7, 5, 'Pro_ject_rpm10.jpg'),
(38, 'Jolida JD102b', '99.00', 'Jolida er god til prisen', 8, 9, 'jolida_JD102b.jpg'),
(39, 'Jolida JD202a', '99.00', 'den virker godt', 8, 9, 'jolida_JD202a.jpg'),
(40, 'Jolida JD300b', '99.00', 'den er alt værd', 8, 9, 'jolida_JD300b.jpg'),
(41, 'Jolida JD302b', '99.00', 'den er skide god og billig', 8, 9, 'jolida_JD302b.jpg'),
(42, 'Jolida JD502b', '99.00', 'Den her er billig, men god', 8, 9, 'jolida_JD502b.jpg');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `idusers` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `users`
--

INSERT INTO `users` (`idusers`, `username`, `password`) VALUES
(2, 'Marie Jensen', '1234');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `accesstokens`
--
ALTER TABLE `accesstokens`
  ADD PRIMARY KEY (`userid`);

--
-- Indeks for tabel `formular`
--
ALTER TABLE `formular`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`ID`), ADD KEY `ID` (`ID`);

--
-- Indeks for tabel `producent`
--
ALTER TABLE `producent`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks for tabel `produkter`
--
ALTER TABLE `produkter`
  ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `navn` (`navn`), ADD KEY `fk_kategori_id` (`fk_kategori_id`), ADD KEY `fk_producent` (`fk_producent`);

--
-- Indeks for tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idusers`), ADD UNIQUE KEY `username` (`username`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `accesstokens`
--
ALTER TABLE `accesstokens`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `formular`
--
ALTER TABLE `formular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- Tilføj AUTO_INCREMENT i tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- Tilføj AUTO_INCREMENT i tabel `producent`
--
ALTER TABLE `producent`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- Tilføj AUTO_INCREMENT i tabel `produkter`
--
ALTER TABLE `produkter`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- Tilføj AUTO_INCREMENT i tabel `users`
--
ALTER TABLE `users`
  MODIFY `idusers` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `produkter`
--
ALTER TABLE `produkter`
ADD CONSTRAINT `produkter_ibfk_1` FOREIGN KEY (`fk_kategori_id`) REFERENCES `kategori` (`ID`),
ADD CONSTRAINT `produkter_ibfk_2` FOREIGN KEY (`fk_producent`) REFERENCES `producent` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
